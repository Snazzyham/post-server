---
title: Facebook open sourced this thing that makes debugging easier
slug: facebook-open-sourced-this-thing-that-makes-debugging-easier
date_published: 2015-08-21T12:49:43.000Z
layout: post
---

*Originally posted on 11/06/2015*

"<blockquote class=""twitter-tweet"" lang=""en""><p lang=""en"" dir=""ltr"">Infer | A static analyzer for mobile apps&#10;&#10;This would have been so useful last semester, for my Java assignment. <a href=""http://t.co/2RuReMCTuF"">http://t.co/2RuReMCTuF</a></p>&mdash; Soham Adwani (@SnazzyHam) <a href=""https://twitter.com/SnazzyHam/status/609218870050598912"">June 12, 2015</a></blockquote> <script async src=""//platform.twitter.com/widgets.js"" charset=""utf-8""></script>

If you visit the [Infer](http://fbinfer.com) website, you'll see this gif of it running. Honestly, this looks pretty cool. It's basically a debugger that gives you possible memory leak and issue errors and stuff, and to be honest, this seems like it would be pretty cool. As far as I can tell, it gives you the issues with your code that a compiler usually wouldn't. I like it. I can't wait to try it out to see how it works. Yay!

Thanks for always open sourcing stuff Facebook <3 "
