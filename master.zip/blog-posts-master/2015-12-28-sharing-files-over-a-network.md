---
title: Sharing files over a network
slug: sharing-files-over-a-network
date_published: 2015-12-28T05:48:19.000Z
date_updated:   2015-12-28T05:48:19.000Z
layout: post
---


I'm a huge fan of tools that make file sharing easier. Over the years I've tried pretty much every tool for file and media sharing over a network, everything from Younity and BitTorrent sync to setting up a samba server. However, the bugs that presented themselves with all those left me to just end up using dropbox for everything instead. 

What sucks is when I have to send files to someone else in my house, like my sister or father. I tried using BT Sync for that but the setup process was always complicated and it annoyed the crap out of everyone in the family so I gave up and started using email instead. ugh, email. AirDrop is cool, but that's an Apple only thing, and I'm the only one in my family that uses a Mac. Wouldn't it be cool if there was an app like AirDrop, but cross platform? 

##Enter Snapdrop. 
Snapdrop is everything I've ever wanted from file sharing. It's so amazing that you don't even have to download an app. There's literally no setup involved. You go to [snapdrop's website](http://snapdrop.net) on both devices, they both show up on each others screens, and you send files. IT'S SO SIMPLE AND SO AMAZING AT THE SAME TIME. 

Seriously, kudos to the [developer](https://github.com/capira12/). This is great work.
