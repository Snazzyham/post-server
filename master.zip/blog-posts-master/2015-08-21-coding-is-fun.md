---
title: Coding is fun
slug: coding-is-fun
date_published: 2015-08-21T12:44:52.000Z
layout: post
---

*Originally posted on 22/03/2015*

It's been about a month of my second semester at uni, and this semester has had a lot more tech related work than ever. I love it. I just got done with probably one of the hardest assignments I've ever had to do, I'm surprised it was only worth 5 marks. Task 1 had us create a program that required us to, you know what I'm not sure I'm allowed to put this online because it's part of an ongoing course. Hmm. 



Well anyway, I've been spending all day at the computer labs this week, literally 10 - 8. It's been wicked fun. Well agonising is more appropriate, but that feeling of figuring out what you did wrong and how to fix it, and then having that suspenseful second where you're waiting to see if your code is going to compile or not. It's insane. Nothing is more ecstatic than the feeling you get of running your code and having it match the required test case outcome. 



Maybe I haven't learned enough for me to call myself a Java or C developer, but I can tell you this. I'm much more of a programmer than I ever have been now, and at this rate, I think I'm going to love this course. 



On a more ironic note, after spending this much time with actual programming. I'm fairly certain I'd want to focus more on web development after graduating. The web is exciting, and it most certainly seems like the future. Facebook, I'm coming for you. 



I've also been looking into design, and I've heard a lot about sketch. I think I'm going to download the demo and try using it. I will return here with my thoughts. 
