---
title: Ambivalence
slug: ambivalence
date_published: 2013-04-12T11:41:00.000Z
layout: post
---

"What am I doing with my life" is a question I have been asking myself a lot these days. I'm neither working nor studying. I wake up in the morning, read a few articles, do a few excercises on codeacademy and watch a few youtube videos. I go to the gym, I listen to podcasts. Some days I'm all in the mood to be a programmer, cramming as much coding knowledge into my head as I can, other days I'm writing scripts and screenplays which I later make into short 2 minute films and post them to YouTube to be forgotten. There are days when all I want to do is be a journalist, report on the latest in technology and business, work alongside the greats like Casey Newton, Ellis Hamburger and Nick Bilton. 

But that's the problem with me. I sit here trying to be too much. Pushing myself to learn everything and I'm left learning a small amount of everything but not enough of anything. As the saying goes "Jack of all trades, Master of none". And what's worse is, I know what I'm doing is wrong but I have no intention to stop. I'm going to keep trying too hard, doing too many things. Mainly it's because I have ADD, I need to keep myself occupied all the time and with different things, untill I figure out how to make that an advantage for me, I guess I'll continue on as I am, an ambivalent human being.

