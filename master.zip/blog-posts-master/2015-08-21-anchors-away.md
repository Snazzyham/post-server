---
title: Anchor's Away
slug: anchors-away
date_published: 2015-08-21T12:44:14.000Z
layout: post
---

*Originally posted on 14/03/2015*

 became a sailor! 



Haha nah, I'm kidding. I did however, get fucking sick of Dropplets, the CMS I was using to host this blog previously. As I had mentioned in the last post, I was fine with it. I got to write in markdown locally and just upload the .md file to my hosting provider. Sure post management wasn't that great, but I did like it. I was annoyed with it a while back when the twitter integration stopped working so it couldn't get my profile picture synced across, so I just ended up customizing the theme and hardcoding my picture from the twitter hosted link thing to the blog. However, a month after, the image started getting issues again. I thought, fuck it. I don't need to use that blog, maybe I'll start using tumblr again. Plus, I was really busy with uni classes anyway. 



Earlier this afternoon, I wanted to blog about how annoying it was that I'm learning C in one class and Java in the other, and both classes are giving us the same problem sets to be done in different languages. Then I was like "welp nah, my code blog is shit. maybe I should just fix that instead." Easy enough, except I needed an outline. also, a CMS. I knew immediately I wanted to use anchor, after [I had written about using it for my about webpage](http://blog.snazzyham.com/index.php/posts/update-jan-2015) but I still looked around for a bit to see if within the time I last did some web work, a new CMS had come out. I decided on Anchor anyway. Then I had to FTP into my current blog and download all the posts to post back on here with the new CMS. Got that done, wiped the dropplets install, installed Anchor and set it up. Then I realised, Anchor doesn't let you upload Markdown posts *(it does have Markdown support, but in the built in text editor only)* so I had to manually do some data entry. Then came problem numero 2, Anchor is still in it's infancy and doesn't allow you to change the date of the post. So all my old blog posts now show as they were posted on today's date; the 19th of March. So to fix that, I just put the date (which thankfully I had cause it was in the .md file thanks to dropplets format thing) at the top of the post. Now that all the backend stuff was done, it was time to think of the design.





I was just gonna stick with the default Anchor theme but I wanted a more geeky yet clean look. I really wanted something that looked like [Marco Arment's blog](http://marco.org). So I went on the Anchor Theme's website and did a lot, and I mean a lot, of searching. Finally I found something that looked close enough to what I wanted, [this guy's theme](https://github.com/wadehammes/anchorcms-blue-theme). This template hasn't been updated in a long time, but I didn't care, it gave me an excuse to brush up on my html and css and at the same time procrastinate from my Organisational Behaviour lecture notes. 



I started off with all the spring cleaning, deleting the hardcoded about me section, deleting the sponsored links thing at the bottom, adding the about me section the heading and fixing up the alignment and other stuff. It was more HTML customising than I had done in a while, the last time I did this much coding was when I built my cousin an ecommerce website. 



Probably the hardest thing to do was enable markdown support. Since this theme was from before Anchor supported markdown, my posts were showing up un-formatted. On top of that, the CSS was messed up. The width was only 660px wide so the text was all clumped together and unreadable. After looking for the right font and doing a lot of CSS maintenance and looking through the Anchor forums on how to enable markdown, it worked! It looks amazing now, well as amazing as can be possible in a couple of hours. Which means its still messy as shit, but it's getting there. 



A friend sitting here had the idea that in the homepage when a user clicks on the post it should just drop down instead of opening into a new page, sorta like an FAQ website. Great idea Paluck, you ever considered shifting to UX design? 



Anyway, till next time my internet friends, happy geeking. 

