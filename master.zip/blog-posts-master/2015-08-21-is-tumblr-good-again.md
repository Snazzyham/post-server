---
title: Is Tumblr Good Again?
slug: is-tumblr-good-again
date_published: 2015-08-21T12:45:32.000Z
date_updated:   2015-04-15T12:45:32.000Z
layout: post
---

Okay maybe not again, but is it good now? I just began writing an article about the best blogging platforms for someone who is looking to start out, and I briefly mentioned tumblr but brushed over it. Today however, I was listening to The Vergecast, and they mentioned something along the lines of how a lot of the people they hired were really popular on Tumblr. I then thought, "people who aren't teens use tumblr?". Then I just forgot about it, until 3am when my brain should have been sleeping but was like "well nah, lets look at what Tumblr does". 



I must say, I'm quite impressed. The design is overhauled and so much more usable. It's nice to see that it wasn't just redesigned for the sake of a redesign, it was redesign to make things more intuitive and familiar, all while making tumblr seem less childish and more serious. There was something else about it, it felt a lot like Medium. I know I may come across as a Medium fanboy, but that's with good reason. I've often said that Medium is what I consider to be a benchmark in good design standards, and it's nice to see tumblr borrowing from that. The new design also gives tumblr more of a serious appearance while still maintaining everything that was quirky and weird about Tumblr, to a bearable extent.



I have a process for the articles I write. The ones I write for Tech in Asia stay on Tech in Asia, the ones I write for Rabelais and The Jakarta Globe get reposted on Medium (It used to be on TechnoCastle before I retired that domain) because Medium lets me target a different and broader audience. However, looking at Tumblr now, it seems like something that could help me grow my audience, so here's what I'm going to do. Instead of just posting links to my Medium articles, I'm going to repost them on both Medium and Tumblr now, to get as wide an audience range as I can. I know this may seem unnecessary, but I've noticed a lot of publishers are doing that with their video content now days so it seems like something that may work, it's worth a shot. It does involve me having to learn how to navigate tumblr, but I'm sure I'll figure it out. 



UPDATE: I spoke to a friend, and apparently she uses Tumblr to pick up dudes. I thought thats what kids used Tinder for? I can't keep up with this shit. 
