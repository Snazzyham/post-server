---
title: Why do I find it so hard to focus on programming
slug: why-do-i-find-it-so-hard-to-focus-on-programming
date_published: 2015-01-29T12:42:24.000Z
date_updated:   2015-01-29T12:42:24.000Z
layout: post
---

*Originally posted on 29/01/2015*

Hello world, I'm back again. Two posts in two days? wow. So as some of you may know, I took [codecademy's HTML and CSS](http://codecademy.com) web development course, and surprisingly finished it. Sure it took me over two years of starting it, getting bored, forgetting about it, starting it all over again. But hey, I finished it. 

Following that I took a break from learning and decided to put my newly learned skills to use, by building websites. I built one for my dad, one for my cousin which never ended up being completed and made endless changes to my own portfolio of websites. 

Around 3 months ago, I decided to start learning again. I didn't want to learn the way I did with HTML and CSS though. I wanted it to be extensive. So I took Harvard's CS50 (an introduction to computer science) course, and I loved it. In one lecture David Malan was able to explain to me what Binary was, something my Computer Science teacher failed to explain to me in 2 years of high school. I got 3 weeks into it, that's 6 lectures, and I got bored. Also, I forgot about everything. 

3 weeks back, I decided to go back into it. I jumped into week 4 and had no idea where I was. I decided to retake it from the beginning. 2 weeks into that and I got bored again. The language was C. 

I thought, you know what? Maybe I'm just not into coding. At the back of my mind, I knew that was a lie. Yesterday, [when I was messing around with my blog's code](http://blog.snazzyham.com/update_jan_2015), was ecstatic. It was the most fun I had in a while. Then it struck me, maybe I'm not into regular development coding. Maybe I'm more into web tech? So for now, I think I'm going to pause CS50, and maybe do Codecademy's PHP lesson first? 



Wish me luck. 


