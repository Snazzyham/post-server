---
title: More Fanboying over Facebook
slug: more-fanboying-over-facebook
date_published: 2016-06-08T06:18:25.000Z
date_updated:   2016-06-08T06:18:25.000Z
layout: post
---

I've written before about the weird obsession I have with wanting to work for Facebook. No, not because of all the perks and stuff. More so, because of the ethos and the way anyone who's ever worked at the place just talks about it with so much passion. It's hard to explain, but read this [brilliant article about Facebook's determination to kill Google Plus](http://www.vanityfair.com/news/2016/06/how-mark-zuckerberg-led-facebooks-war-to-crush-google-plus) and you'll kinda get the idea.  

This is a short blog post, and I'm pretty much using it as a place to store this link so I can read it again later. 
