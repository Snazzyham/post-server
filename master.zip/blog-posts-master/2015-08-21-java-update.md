---
title: Java Update - I'm getting better
slug: java-update
date_published: 2015-04-22T12:46:31.000Z
layout: post
---

Well, exams are around the corner, and the stress level is real. On the other hand, in this past month, I've really become more confident in my coding skills. I guess I realised I was getting better when I watched a video on the google developers channel, and went "ahh yeah okay.. wait a minute, I UNDERSTAND THIS SHIT!". 



And you know how I said I found it really hard? I still do, but weirdly, I find it fun as well. Like on the last assignment, I probably spent 70 hours doing it, and I didn't even mind. It may have made me emotional every time I got a *NullPointerException* (which I got a lot of), but that feeling of getting it done was actually one of the most fulfilling feelings ever. I ended up getting a 93 / 100 on Assignment 2, and 78 on Assignment 3, which Assignment 3 I could have gotten better but I started it a bit late given I had other stuff, but I was seriously proud given in the first assignment I only got a 50 / 100. 



On top of that, I'm actually getting used to Java. So much more that I'm gonna say I prefer Java to C. I can't tell you how many times I've tried to initialise a string thing in C and run into weird ass errors. C is fine, Java is just better IMO. 



Maybe I got better when I stopped using Vi? Seriously why do people use Vi. Some people say it makes you a faster coder, not me. It made me waste so much time. I got so much faster when I switched to Sublime. Well I gave Microsoft's Visual Studio Code a shot at first and it was nice, but Sublime's code completion for Java is just so much better. 



On to another assignment, ITF. I had to build a web store thingy, which I thought would be easy enough given I've made e-commerce websites before, and much more complex ones that what was required. Oh wait, I'm not allowed to use a CMS? Everything has to be done from scratch? That's what fucked me. I got used to SQL quicker than I assumed, but friggin PHP tho. It was all fine at first, once I got used PDO it was getting okay, and then I had an issue where my cart would only show one of the items. 4 hours later. Same problem. You wanna know what was wrong? ONE SPACE. ONE FRIGGIN SPACE. It was (variable, comma, space, variable) and it had to be (variable, comma, variable). ONE SPACE TOOK 4 HOURS AWAY FROM MY LIFE. It was cool though, cause know I finally know why everyone bitches about PHP. 
