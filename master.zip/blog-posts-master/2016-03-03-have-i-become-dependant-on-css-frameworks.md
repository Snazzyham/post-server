---
title: Have I become dependant on CSS Frameworks?
slug: have-i-become-dependant-on-css-frameworks
date_published: 2016-03-03T01:06:25.000Z
date_updated:   2016-03-03T01:06:25.000Z
layout: post
---

There's no denying it, CSS frameworks are great. Some might say that they bloat up websites, and have way more content than you actually need, but others will tell you that they're a blessing. I've been using CSS frameworks in every project I've done since 2015. Well, all projects except one, Spencer. Spencer was more mobile centric, and didn't have any CSS elements per-say, as all it's design elements were designed in house at Percolate Galactic. 

Back to the main part of this story. I'm currently sitting in a class called CSE2ICE - Internet Client Engineering. The goal for the end of this class, to build a website. Ironic. I know. However, this website would have to be built from scratch. That includes all my own CSS. It's not impossible, and I'm definitely excited. Who knows, by the end of this class I may actually end up building my own CSS framework. OH MY GOD THAT'S WHAT I'M GOING TO DO. I'M GOING TO BUILD A CSS FRAMEWORK. 

I am very excited. Also, I've got Mitch and Phil on my team, so there should be some fun coding sessions. 

