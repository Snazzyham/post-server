---
title: Windows 8.1U1 Wishlist and Rant
slug: windows-8-1u1-wishlist-and-rant
date_published: 2015-08-21T11:37:22.000Z
date_updated:   2015-08-21T11:37:22.000Z
layout: post
---

######What will it take for my love for windows to return?

Below is an excerpt of my rant on Windows.

>Then, in the first week of 2014, I had enough. Windows had crashed on me for the nth time. I bit the bullet, not in the way that you’d expect it. I cloned my windows install from my PC and put it on my laptop, deleting ubuntu, and I hackintoshed my PC. I am now a proud and happy Mac user. I love the OS, it’s overall more stable, it is much more productive and I won’t bore you with all the details, I’ll save that for a later rant. Sometimes however, I consider switching back. 

The above rant can be found at [Medium.com](https://medium.com/p/fdf34b70e224)


