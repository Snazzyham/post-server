---
title: Phonebloks
slug: phonebloks
date_published: 2015-08-21T11:34:41.000Z
date_updated:   2013-09-14T11:34:41.000Z
layout: post
---

Hey there internet folk! So some of you may have heard about phonebloks, if you haven't you can check out the video [here](https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=2&cad=rja&ved=0CDQQtwIwAQ&url=http%3A%2F%2Fwww.youtube.com%2Fwatch%3Fv%3DoDAw7vW7H0c&ei=O0k0Up7PH8SGrgf8yoHwCQ&usg=AFQjCNFLqSFT_17NMUSK-78ns4BDN2CcZA&sig2=GavDQrCeOeehtmSLDjFA4A&bvm=bv.52164340,d.bmk). What phonebloks basically is, is a concept of Lego for phones. So you get to customise your phone's parts and focus on the things you want. Instead of just throwing away your phone you can throw away the part you don't want. This sort of technique has actually existed for quite a while in the tech industry, where we mix and match our PC's components, and it's just taking that concept and making it mobile, as we seem to do with everything [else](http://www.theverge.com/2013/9/12/4722470/iphone-5s-64-bit-processor-is-a-bigger-deal-than-you-think) these days, but it's actually making it easier. However that's probably all that it'll be, a concept. 

If you think about it, as MKBHD explains in this brilliant [video](http://www.youtube.com/watch?v=IovZRv8toDM), the cost of the phone is actually going to be really high as it costs way more to build a small product or component rather than integrating it. Also, manufacturers wouldn't really have any reason to build these components. Why would nokia build a 41 megapixel camera for phonebloks when they wan't people to buy the Lumia 1020? Also, Microsoft now owns Nokia, why would they want to build something for a phone that most probably will not run Windows Phone? The concept just doesn't live up to reality. Don't get me wrong, I love the concept but I had my doubts and when I watched MKBHD's video, that was my confirmation. This actually really saddens me.. I wanted the Ubuntu Edge to succeed and it seemed like it really would but it just didn't work out. 

Some manufacturers would actually love to produce for phonebloks, but those would be the manufacturers that haven't entered the phone market as yet but want to and know that if they try to enter the market by themselves they're not going to have a shot at it, unless they are as clueless as Blackberry in which case good on you man. 

I guess that's all I have to say about this, stay tuned for more opinions and what not. See ya folks. 
