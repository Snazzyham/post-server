---
title: Windows Woes
slug: windows-woes
date_published: 2016-01-31T12:45:02.000Z
date_updated:   2016-01-31T12:45:02.000Z
layout: post
---

It's fascinating how setting up a dev environment on Mac and Linux take about a minute or so, and trying to do the same thing on Windows can take hours. Sure, at the end you get the same result, but getting there is so much faster on a Mac. 

I've spent the most of today trying to get Grav, a flat file PHP based CMS, set up locally on my computer. To do that, I would need a web server. On a Unix machine, it's easy as can be. I just have to type `apache start` and I'm good to go. On Windows? Well I tried installing XAMPP, but that had problems with getting access to port 80. So I was told to delete something from *services.msc*. To bad that thing I was told to delete didn't exist. So, I decided to try IIS with PHP or whatever. Now, this isn't some janke 3rd party software. This is official Microsoft software. It refused to install. Rather than going through that whole time waste of trying to figure out how to fix those errors, I decided to just fuck it and install fedora instead. 

What does that say about windows, that a developer would rather install a completely new operating system than deal with its garbage software issues. 

I love Windows 10. It's been my favourite iteration of the OS, and I've been using Windows all my life. It's way more functional than windows 7 and it even looks bloody gorgeous. However, the more I've been playing around in the world of web development, the more I've grown annoyed with Windows and its bullshit. 

 I can't believe I'm saying this, especially with all the advancements Microsoft made in Windows 10, but Windows, *why do you suck so much?*
