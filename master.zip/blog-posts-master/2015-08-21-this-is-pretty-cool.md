---
title: This is pretty cool
slug: this-is-pretty-cool
date_published: 2015-07-04T12:51:27.000Z
layout: left-post
---

*Originally posted on 07/04/2015*

>We suspected that mobile users would constitute a majority of our traffic. Fortunately, our web stack provides simple abstractions to deliver content optimized for desktop and mobile. Taking advantage of this, we developed an initial concept for desktop and then reused our code for mobile, placing our product in Facebook for iOS, Android, and mobile web in just a few hours.

If you're interested in how big companies such as facebook set about developing new features and pushing it, how long the time gap between inception and distribution is, and anything else about code pushes, you might want to read [this article about how Facebook pushed their celebrate pride profile picture feature](https://code.facebook.com/posts/778505998932780/72-hours-to-launch-celebrate-pride/). 

I find it fascinating, everything from how they set about deciding when to push it to how they realised their mistake so quickly and managed to change it. 
