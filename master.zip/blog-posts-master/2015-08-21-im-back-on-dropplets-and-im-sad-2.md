---
title: I'm back on Dropplets and I'm sad.
slug: im-back-on-dropplets-and-im-sad-2
date_published: 2015-08-21T12:50:32.000Z
layout: post
---

*Originally posted on 30/06/2015*

So, the blog went down for about a week. The reason for this, the shared hosting provider I'm on decided to move my files to a different server. This did something weird to the PHP settings and anchor (the CMS I deeply fell in love with) decided to stop working. I  spent a whole week trying to figure out why, to no avail. I've tried around 15 PHP based CMS' since, none of them worked. My beautiful theme, my beloved Anchor back-end, all gone. 

To top that all off, since all my posts were written on Anchor, I didn't have the markdown files saved. Yes, that was my stupidity. So what I spent this morning doing was exporting my SQL database from PHPMyAdmin to CSV, opening it in Excel and copy-pasting the articles into Markdown files, re-setting up Dropplets on the server and uploading all the files, and editing the dropplets theme to remove the weird broken twitter picture import thing that it tries to do. 

There are many things I'm sad about when it comes to leaving Anchor, but most of all I'll miss the theme I had on it, I can try to remake it for Dropplets, but I'll have to figure out how to get WAMP to run without my computer freaking the fuck out. It'll be a fun challenge and I look forward to it. I'm also planning on Materializing the standard dropplets install. More on that later. One thing I'll miss the most is the WYSIWYG editor. When I first came on to Dropplets, it was so freeing being able to use my own editor. However, coming back to this now, it's a drag. Having to manually upload files to the server, it's less than ideal. Plus, I have to memorise the whole process of how to get the metadata right for Dropplets, ugh.

Also the dropplets theme doesn't seem to recognize the intro stuff so my about me from the top is missing (the small section where I link to my Medium and Twitter) so it'll take me a bit to figure that out. I tried hardcoding it but it broke the theme. Oops. 

I'll see you soon, interwebs. 
