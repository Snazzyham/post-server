---
title: First Post Here and Life Update
slug: first-post-here-and-life-update
date_published: 2015-08-21T12:40:18.000Z
layout: post
---

*originally posted on 13/09/2013*

Hey there internet folk. So by now you're probably confused. This domain used to just redirect to a flavors.me site where you could find out about me and it had a pretty slick design. No doubt I still love the design I made for that (pretty much hate it too) because I mean that's the problem with a lot of things that I do. You can still get access to that if you want at flavors.me/snazzyham. Also, technocastle has a nice look but I've been wanting to get it onto it's own domain, customise the entire site and build it as a standalone site with the wordpress plugin rather than having it as jsut another wordpress.com site. One problem with that is that it takes up a lot of time to build and I don't want to waste time building it if people aren't even going to be bothered to come to the site. Especially since I'm not even sure if I'll be monetizing it. 

So now you're wondering what this blog is for. Well this is going to be my main blog for now, I'll write all my posts here, including the technology ones and everything else that I feel like writing about and later on if I do end up customising the look and feel of technocastle and set it up as a proper site then I'll migrate over all the tech posts from this blog to technocastle but will still post here for the other stuff. 

I love how this site is so simple and plain but I plan on going into the code sometime in the future and customising the look and feel a bit, it has default twitter links but I want to try and find a way to make it a bit more custom. 

So yeah I guess that's it, welcome to my brain, you now have access to all my thoughts, opinions, feelings and emotions. Enjoy! 
