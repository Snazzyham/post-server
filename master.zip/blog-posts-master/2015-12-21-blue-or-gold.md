---
title: Blue or Gold?
slug: blue-or-gold
date_published: 2015-12-21T15:04:33.000Z
date_updated:   2015-12-21T15:04:33.000Z
layout: post
---

Yes, I'm talking about the dress. No, it's not what you think it is. I've recently been scouring the webs looking for decent engineering blogs to add to my feedly, and boy does BuzzFeed have an amazing dev blog. I know right? Who would've known. 

Read [this article](http://www.buzzfeed.com/daozers/what-its-like-to-work-on-buzzfeeds-tech-team-during-record-t#.ydvYEwrrA) about how they handled the server loads on their busiest ever day in history, the day that damned blue and white (or black and gold) dress appeared on the internet. 

Seriously, if you're into tech, such a good read.
