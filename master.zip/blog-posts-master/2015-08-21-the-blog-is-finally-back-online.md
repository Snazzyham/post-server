---
title: The blog is finally back online!
slug: the-blog-is-finally-back-online
date_published: 2015-08-21T16:04:17.000Z
layout: post
---

If you'd visited my blog in the past couple of days, you might have been redirected to my tumblr, which had a [post explaining why my blog was down](http://snazzyham.tumblr.com). Long story short, the shared server I was on got shut down and I had to find a new place to host my stuff, and once I did that, I had to re-setup my blog. Now that I was on a new server, I thought of maybe going back to Anchor [since the last server I was with broke the install I had of Anchor](http://blog.snazzyham.com/im-back-on-dropplets-and-im-sad-2/) and I had to go back to Dropplets. I was thinking of maybe just sticking with Dropplets, but that wasn't as nice as Anchor (not to mention with Anchor I already had a theme I had spent quite a few hours working on and it was beginning to look just how I wanted). 

So yeah, I decided to go back to Anchor. That didn't seem to work for some reason. The install kept having issues and then it worked but I couldn't access the admin panel for some reason, after all this struggling I've been going through with the blog I decided to just call it quits and go with Dropplets again. Except, that didn't really work. For some unknown reason, the Dropplets CSS wasn't loading. I tried a lot of things, still couldn't get it to work. I was this close to just re-posting all my old blog posts on tumblr and using that as my blog instead, but I really couldn't find any theme that I liked. It was then when I realised something, I'm no longer on that shitty server I was using, which means I can go back to trying out Ghost! 

A few minutes later (God bless you Softaculous) and ta-da! I'm on Ghost now. Took me less time than I expected to re-post all my blog posts on to Ghost, but they're all here now and I'm a happy kid. I'm still using the default Ghost theme as I haven't had the time to figure out how themes work on this yet (apparently you need to re-start ghost everytime you upload a new theme, but I'm on a shared server so I don't really know how to do that) plus I haven't found the exact one I want to use yet. I was thinking of maybe just going off the vanilla "Casper" theme and throwing on some [Material Design Lite](http://www.getmdl.io) goodness on there, but we'll see how it goes. 
