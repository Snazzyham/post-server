---
title: It's time to learn how to code
slug: its-time-to-learn-how-to-code
date_published: 2013-11-11T11:38:20.000Z
layout: post
---

Yes, I know I have always said that I wanted to learn how to code and slowly I have been learning. i tried learning Java at school but sadly, I think I must've forgotten how to write even a simple GIGO program by now. For those of you lesser tech informed humans, GIGO stands for "Garbage In Garbage Out". An acronymisation (or acronymization for you American folk) of a program that does nothing but output certain data to the user, not requiring any input or calculation. 

So after my failed attempt at Java, I tried learning html, be it from some various sources online, to some books I read. I knew enough html to get me through basic stuff but it was never really to the level that I wanted it to be. 

You must be wondering, why do I want to learn to code so bad if it didn't work out the last time? Why do I keep trying again and again? Well the simple truth to it all, coding is essential to what I want to do. I want to work in the tech industry, I want to be able to understand everything related to technology and it's systems and for that I require an understanding of a few programming languages. I want to be able to solve problems, to be able to create working programs by just typing up a variation of code. I want to be like Mark Zuckerberg's fictional representation in "The Social Network" as portrayed by Jesse Esienberg. 

So now the steps I've taken; As I mentioned I never really studied HTML seriously, but I'm going to now. I'm starting with HTML and CSS and am 25% through codeacademy's Web Fundamentals class. I find that I've learned more with a couple of days on codeacademy as compared to hours spent watching Lynda.com tutorials. After I'm done with the web fundamentals I'm probably going to try mixing it up and giving PHP a go before I move on to JavaScript. Following that I will try to learn Ruby/Rails if I get the chance and motivation to and I won't stop till I have dominated at least 8 essential languages, and no COBOL doesn't count. 

I shall be chronicling my journey here on this blog so stay tuned my fellow enthusiasts and heck, maybe help me on the motivation side of things. 
