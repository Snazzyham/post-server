---
title: Code Journal Day 2
slug: code-journal-day-2
date_published: 2013-12-11T12:38:37.000Z
layout: post
---


I'm day 2 into my "I wanna be serious about coding" phase and so far, I haven't been that serious. I've actually been quite lazy and sleepy today. In the morning I went to dad's office to continue teaching him how to use the new inventory management system I had implemented to try and make his life easier. It has potential but right now, well its a long story. 

Subsequent to my half day at the office, I returned home to indulge in Edgar Wright's The Worlds End, a film I had been longing to view with my eyeballs since I saw the trailer. It was not bad. *Et puis* I went for a swim, cause it was going to rain and apparently I work differently from most human beings. 

Only after that; which was about 6pm, did I decide to sit my ass down and get on codeacademy. I only completed another 12% or so of the Web Fundamentals course today, completing tables and getting a small look into CSS. Although I didn't really learn much, I learned enough to fix something that has been irking me for the past 3 months. Ever since I switched to dropplets as my CMS for my blog, I've loved the design safe for one feature. I couldn't change the bloody font. As some of you may know I love fonts so obviously this was a pain in the ass for me. Now dropplets doesn't really allow Custom CSS so what I did was add the " < style ></ style > " tag to the <span style="color:red">"Code Injection"</span> section and input some low level CSS into that and viola. I was able to change the font. I'm seeing the benefits of programming already.

<em>Probably something I should have known from the beginning but didn't is that I can incorporate some html and css elements in my composition of this blog as well, as denoted by the useless blue div you see below. A very doge moment this has been. Also I wonder if I can make use of gifs, something I shall try out in a later post perhaps. </em>
<br>
>
<div style="widht: 60px; height:60px; background-color:blue"></div>
