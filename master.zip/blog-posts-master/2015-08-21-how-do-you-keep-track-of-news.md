---
title: How do you keep track of news
slug: how-do-you-keep-track-of-news
date_published: 2015-08-21T12:41:06.000Z
layout: post
---

*09/16/2013*

News is probably one of the biggest parts of your day, even if you don't realise it. Reading this post is technically a form of news in one way, although if it's relevant news that's for you to decide. It sometimes get's hard to keep track of the sources and sites that we get our news from and how we manage and sort all of it plays a huge part in how we keep ourselves updated with the world. 

Most people prefer using rss readers, as it allows them to organise their sources into folder and mark what they have or have not read. Some people do it the old fashioned way and read newspapers.. good on them! I personally have digg reader installed, but use twitter more often to keep up to date. I follow important accounts that I want the latest information immediately from and keep the other sources in digg reader, the sources I don't necessarily feel share articles I would like to read immediately. When I'm skimming through and find something that I'm interested in but don't particularly have the time to read it I just save it to pocket. 

As much as I'd like to say that I'm really organised with my news and have one centralised location for all my articles, truth is I'm pretty messy. Sometimes my news comes from facebook and even linkedin, a lot of the time it's from a podcast or youtube videos, but most of the time I just go to [The Verge](http://theverge.com) or [TechnoBuffalo](http://technobuffalo.com) and check out the articles there. 

What about you guys? Do you have a centralised source for news or do you get your information from all over the place? 
